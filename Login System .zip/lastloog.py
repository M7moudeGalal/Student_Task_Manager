from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1061, 600)
        Form.setAttribute(Qt.WA_TranslucentBackground)
        Form.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)
        Form.setWindowFlags(QtCore.Qt.WindowType.FramelessWindowHint)
        self.widget = QtWidgets.QWidget(parent=Form)
        self.widget.setGeometry(QtCore.QRect(9, 19, 1011, 561))
        self.widget.setObjectName("widget")
        self.label = QtWidgets.QLabel(parent=self.widget)
        self.label.setGeometry(QtCore.QRect(10, 0, 501, 551))
        self.label.setStyleSheet(
    "border-image: url(C:/Users/EL-MOHANDES/Desktop/guiProject/back.jpg);"
    "border-top-left-radius: 50px;"
    "border-bottom-left-radius: 50px;"
)

        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(parent=self.widget)
        self.label_2.setGeometry(QtCore.QRect(510, 0, 501, 551))
        self.label_2.setStyleSheet("background-color:rgb(255, 255, 255);\n"
"border-top-right-radius: 50px;\n"
"border-bottom-right-radius: 50px;\n"
"\n"
"")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(parent=self.widget)
        self.label_3.setGeometry(QtCore.QRect(710, 40, 100, 40))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("color:rgba(0, 0, 0, 200);")
        self.label_3.setObjectName("label_3")
        self.lineEdit = QtWidgets.QLineEdit(parent=self.widget)
        self.lineEdit.setGeometry(QtCore.QRect(560, 150, 381, 40))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit.setFont(font)
        self.lineEdit.setStyleSheet("background-color: rgba(0, 0, 0, 0); /* خلفية شفافة */\n"
"border: none;\n"
"border-bottom: 2px solid rgba(46, 82, 101, 0.8); /* استخدمي rgba بدل rgb مع قيمة شفافية */\n"
"color: rgba(0, 0, 0, 0.8); /* اللون مع شفافية مناسبة */\n"
"padding-bottom: 7px; /* كانت مكتوبة غلط: padding-bootom */\n"
"")
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_2 = QtWidgets.QLineEdit(parent=self.widget)
        self.lineEdit_2.setGeometry(QtCore.QRect(560, 240, 381, 40))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_2.setFont(font)
        self.lineEdit_2.setStyleSheet("background-color: rgba(0, 0, 0, 0); /* خلفية شفافة */\n"
"border: none;\n"
"border-bottom: 2px solid rgba(46, 82, 101, 0.8); /* استخدمي rgba بدل rgb مع قيمة شفافية */\n"
"color: rgba(0, 0, 0, 0.8); /* اللون مع شفافية مناسبة */\n"
"padding-bottom: 7px; /* كانت مكتوبة غلط: padding-bootom */\n"
"")
        self.lineEdit_2.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.pushButton = QtWidgets.QPushButton(parent=self.widget)
        self.pushButton.setGeometry(QtCore.QRect(570, 330, 371, 61))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("""
QPushButton#pushButton {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(127, 207, 168, 255),
        stop:0.5 rgba(95, 160, 135, 255),
        stop:1 rgba(127, 207, 168, 255));
    color: white;
    border-radius: 20px;
    padding: 8px 20px;
}

QPushButton#pushButton:hover {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(137, 217, 178, 255),
        stop:0.5 rgba(65, 110, 93, 255),
        stop:1 rgba(137, 217, 178, 255));
}

QPushButton#pushButton:pressed {
    padding-top: 5px;
    padding-left: 5px;
    background-color: rgb(55, 100, 85);
}

QPushButton#pushButton_2 {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1,
        stop:0 rgba(127, 207, 168, 255),
        stop:0.5 rgba(95, 160, 135, 255),
        stop:1 rgba(127, 207, 168, 255));
    color: white;
    border-radius: 20px;
    padding: 8px 20px;
    border: none;
}

QPushButton#pushButton_2:hover {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1,
        stop:0 rgba(137, 217, 178, 255),
        stop:0.5 rgba(65, 110, 93, 255),
        stop:1 rgba(137, 217, 178, 255));
}

QPushButton#pushButton_2:pressed {
    padding-top: 5px;
    padding-left: 5px;
    background-color: rgb(55, 100, 85);
}
""")
        self.pushButton.setObjectName("pushButton")
        self.label_5 = QtWidgets.QLabel(parent=self.widget)
        self.label_5.setGeometry(QtCore.QRect(660, 420, 231, 21))
        self.label_5.setStyleSheet("color: rgba(0, 0, 0, 0.82); /* ✅ شفافية 82% تقريبًا */\n"
"")
        self.label_5.setObjectName("label_5")
        self.pushButton_2 = QtWidgets.QPushButton(parent=self.widget)
        self.pushButton_2.setGeometry(QtCore.QRect(750, 410, 81, 40))
        self.pushButton_2.setMaximumSize(QtCore.QSize(100, 40))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("QPushButton#pushButton_2 {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(152, 251, 203, 255),\n"
"        stop:0.33 rgba(127, 207, 168, 255),\n"
"        stop:0.66 rgba(85, 139, 113, 255),\n"
"        stop:1 rgba(69, 110, 93, 255));\n"
"    color: white;\n"
"    border-radius: 20px;\n"
"    padding: 8px 20px;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton#pushButton_2:hover {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(152, 251, 203, 255),\n"
"        stop:0.33 rgba(127, 207, 168, 255),\n"
"        stop:0.66 rgba(95, 165, 135, 255),\n"
"        stop:1 rgba(69, 110, 93, 255));\n"
"}\n"
"\n"
"QPushButton#pushButton_2:pressed {\n"
"    padding-top: 5px;\n"
"    padding-left: 5px;\n"
"    background-color: rgb(69, 110, 93);\n"
"}\n")
        self.pushButton_2.setObjectName("pushButton_2")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label_3.setText(_translate("Form", "LogIn"))
        self.lineEdit.setPlaceholderText(_translate("Form", "User Name"))
        self.lineEdit_2.setPlaceholderText(_translate("Form", "Password"))
        self.pushButton.setText(_translate("Form", "LogIn"))
        self.label_5.setText(_translate("Form", "No account yet?"))
        self.pushButton_2.setText(_translate("Form", "SignUp"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec())
