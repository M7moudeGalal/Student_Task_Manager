from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1061, 600)
        Form.setAttribute(Qt.WA_TranslucentBackground)
        Form.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)
        Form.setWindowFlags(QtCore.Qt.WindowType.FramelessWindowHint)
        font = QtGui.QFont()
        font.setFamily("Marlett")
        font.setPointSize(10)
        Form.setFont(font)
        self.widget = QtWidgets.QWidget(parent=Form)
        self.widget.setGeometry(QtCore.QRect(9, 19, 1011, 561))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(10)
        self.widget.setFont(font)
        self.widget.setObjectName("widget")
        self.label = QtWidgets.QLabel(parent=self.widget)
        self.label.setGeometry(QtCore.QRect(10, 20, 911, 531))
        font = QtGui.QFont()
        font.setFamily("Roman")
        font.setPointSize(9)
        self.label.setFont(font)
        self.label.setStyleSheet(
    "border-image: url(C:/Users/EL-MOHANDES/Desktop/guiProject/intro.webp);"
    "border-top-left-radius: 50px;"
    "border-bottom-left-radius: 50px;"
)

        self.label.setText("")
        self.label.setObjectName("label")
        self.pushButton_2 = QtWidgets.QPushButton(parent=self.widget)
        self.pushButton_2.setGeometry(QtCore.QRect(380, 490, 191, 41))
        font = QtGui.QFont()
        font.setFamily("Segoe Print")
        font.setPointSize(15)
        font.setBold(True)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("""
QPushButton#pushButton_2 {
    background-color: qlineargradient(
        spread:pad,
        x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(69, 110, 93, 255),         
        stop:0.33 rgba(95, 165, 135, 255),    
        stop:0.66 rgba(95, 165, 135, 255),     
        stop:1 rgba(69, 110, 93, 255)          
    );
    color: white;
    border-radius: 20px;
    padding: 8px 20px;
    border: none;
}

QPushButton#pushButton_2:hover {
    background-color: qlineargradient(
        spread:pad,
        x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(85, 139, 113, 255),
        stop:0.33 rgba(127, 207, 168, 255),
        stop:0.66 rgba(127, 207, 168, 255),
        stop:1 rgba(85, 139, 113, 255)
    );
}

QPushButton#pushButton_2:pressed {
    padding-top: 5px;
    padding-left: 5px;
    background-color: rgb(69, 110, 93);
}
""")
        self.pushButton_2.setObjectName("pushButton_2")
        self.label_3 = QtWidgets.QLabel(parent=self.widget)
        self.label_3.setGeometry(QtCore.QRect(320, 170, 341, 40))
        font = QtGui.QFont()
        font.setFamily("Segoe Print")
        font.setPointSize(28)
        font.setBold(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("color: rgb(255, 255, 255);")
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(parent=self.widget)
        self.label_4.setGeometry(QtCore.QRect(350, 240, 481, 40))
        font = QtGui.QFont()
        font.setFamily("Segoe Print")
        font.setPointSize(10)
        font.setBold(True)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("color: rgb(255, 255, 255);")
        self.label_4.setObjectName("label_4")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.pushButton_2.setText(_translate("Form", "Get Start"))

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec())
