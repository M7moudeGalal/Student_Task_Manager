from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1061, 600)
        Form.setAttribute(Qt.WA_TranslucentBackground)
        Form.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)
        Form.setWindowFlags(QtCore.Qt.WindowType.FramelessWindowHint)
        font = QtGui.QFont()
        font.setFamily("Marlett")
        font.setPointSize(10)
        Form.setFont(font)
        self.widget = QtWidgets.QWidget(parent=Form)
        self.widget.setGeometry(QtCore.QRect(9, 19, 1011, 561))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(10)
        self.widget.setFont(font)
        self.widget.setObjectName("widget")
        self.label = QtWidgets.QLabel(parent=self.widget)
        self.label.setGeometry(QtCore.QRect(10, 0, 501, 551))
        self.label.setStyleSheet(
    "border-image: url(C:/Users/EL-MOHANDES/Desktop/guiProject/back.jpg);"
    "border-top-left-radius: 50px;"
    "border-bottom-left-radius: 50px;"
)


        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(parent=self.widget)
        self.label_2.setGeometry(QtCore.QRect(510, 0, 501, 551))
        self.label_2.setStyleSheet("background-color:rgb(255, 255, 255);\n"
"border-bottom-right-radius:50px;\n"
"border-top-right-radius:50px;")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(parent=self.widget)
        self.label_3.setGeometry(QtCore.QRect(710, 40, 100, 40))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(20)
        font.setBold(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("color:rgba(0, 0, 0, 200);")
        self.label_3.setObjectName("label_3")
        self.user_name = QtWidgets.QLineEdit(parent=self.widget)
        self.user_name.setGeometry(QtCore.QRect(560, 120, 381, 31))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(10)
        self.user_name.setFont(font)
        self.user_name.setStyleSheet("background-color: rgba(0, 0, 0, 0); /* خلفية شفافة */\n"
"border: none;\n"
"border-bottom: 2px solid rgba(46, 82, 101, 0.8); /* استخدمي rgba بدل rgb مع قيمة شفافية */\n"
"color: rgba(0, 0, 0, 0.8); /* اللون مع شفافية مناسبة */\n"
"padding-bottom: 7px; /* كانت مكتوبة غلط: padding-bootom */\n"
"")
        self.user_name.setText("")
        self.user_name.setObjectName("user_name")
        self.lineEdit_2 = QtWidgets.QLineEdit(parent=self.widget)
        self.lineEdit_2.setGeometry(QtCore.QRect(560, 280, 381, 40))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(10)
        self.lineEdit_2.setFont(font)
        self.lineEdit_2.setStyleSheet("background-color: rgba(0, 0, 0, 0); /* خلفية شفافة */\n"
"border: none;\n"
"border-bottom: 2px solid rgba(46, 82, 101, 0.8); /* استخدمي rgba بدل rgb مع قيمة شفافية */\n"
"color: rgba(0, 0, 0, 0.8); /* اللون مع شفافية مناسبة */\n"
"padding-bottom: 7px; /* كانت مكتوبة غلط: padding-bootom */\n"
"")
        self.lineEdit_2.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.pushButton = QtWidgets.QPushButton(parent=self.widget)
        self.pushButton.setGeometry(QtCore.QRect(570, 430, 371, 61))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(12)
        font.setBold(True)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("""
QPushButton#pushButton {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(127, 207, 168, 255),
        stop:0.5 rgba(95, 160, 135, 255),
        stop:1 rgba(127, 207, 168, 255));
    color: white;
    border-radius: 20px;
    padding: 8px 20px;
}

QPushButton#pushButton:hover {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(137, 217, 178, 255),
        stop:0.5 rgba(65, 110, 93, 255),
        stop:1 rgba(137, 217, 178, 255));
}

QPushButton#pushButton:pressed {
    padding-top: 5px;
    padding-left: 5px;
    background-color: rgb(55, 100, 85);
}

QPushButton#pushButton_2 {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1,
        stop:0 rgba(127, 207, 168, 255),
        stop:0.5 rgba(95, 160, 135, 255),
        stop:1 rgba(127, 207, 168, 255));
    color: white;
    border-radius: 20px;
    padding: 8px 20px;
    border: none;
}

QPushButton#pushButton_2:hover {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1,
        stop:0 rgba(137, 217, 178, 255),
        stop:0.5 rgba(65, 110, 93, 255),
        stop:1 rgba(137, 217, 178, 255));
}

QPushButton#pushButton_2:pressed {
    padding-top: 5px;
    padding-left: 5px;
    background-color: rgb(55, 100, 85);
}
""")
        self.pushButton.setObjectName("pushButton")
        self.lineEdit_3 = QtWidgets.QLineEdit(parent=self.widget)
        self.lineEdit_3.setGeometry(QtCore.QRect(560, 360, 381, 40))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(10)
        self.lineEdit_3.setFont(font)
        self.lineEdit_3.setStyleSheet("background-color: rgba(0, 0, 0, 0); /* خلفية شفافة */\n"
"border: none;\n"
"border-bottom: 2px solid rgba(46, 82, 101, 0.8); /* استخدمي rgba بدل rgb مع قيمة شفافية */\n"
"color: rgba(0, 0, 0, 0.8); /* اللون مع شفافية مناسبة */\n"
"padding-bottom: 7px; /* كانت مكتوبة غلط: padding-bootom */\n"
"")
        self.lineEdit_3.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.lineEdit_4 = QtWidgets.QLineEdit(parent=self.widget)
        self.lineEdit_4.setGeometry(QtCore.QRect(560, 190, 381, 40))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(10)
        self.lineEdit_4.setFont(font)
        self.lineEdit_4.setStyleSheet("background-color: rgba(0, 0, 0, 0); /* خلفية شفافة */\n"
"border: none;\n"
"border-bottom: 2px solid rgba(46, 82, 101, 0.8); /* استخدمي rgba بدل rgb مع قيمة شفافية */\n"
"color: rgba(0, 0, 0, 0.8); /* اللون مع شفافية مناسبة */\n"
"padding-bottom: 7px; /* كانت مكتوبة غلط: padding-bootom */\n"
"")
        self.lineEdit_4.setText("")
        self.lineEdit_4.setEchoMode(QtWidgets.QLineEdit.EchoMode.Normal)
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.pushButton_2 = QtWidgets.QPushButton(parent=self.widget)
        self.pushButton_2.setGeometry(QtCore.QRect(710, 500, 71, 41))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(7)
        font.setBold(True)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("QPushButton#pushButton_2 {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(152, 251, 203, 255),\n"
"        stop:0.33 rgba(127, 207, 168, 255),\n"
"        stop:0.66 rgba(85, 139, 113, 255),\n"
"        stop:1 rgba(69, 110, 93, 255));\n"
"    color: white;\n"
"    border-radius: 20px;\n"
"    padding: 8px 20px;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton#pushButton_2:hover {\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,\n"
"        stop:0 rgba(152, 251, 203, 255),\n"
"        stop:0.33 rgba(127, 207, 168, 255),\n"
"        stop:0.66 rgba(95, 165, 135, 255),\n"
"        stop:1 rgba(69, 110, 93, 255));\n"
"}\n"
"\n"
"QPushButton#pushButton_2:pressed {\n"
"    padding-top: 5px;\n"
"    padding-left: 5px;\n"
"    background-color: rgb(69, 110, 93);\n"
"}\n"
)
        self.pushButton_2.setObjectName("pushButton_2")
        self.label_4 = QtWidgets.QLabel(parent=self.widget)
        self.label_4.setGeometry(QtCore.QRect(670, 510, 51, 21))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(8)
        font.setBold(False)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("color:rgba(0, 0, 0, 200);")
        self.label_4.setObjectName("label_4")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label_3.setText(_translate("Form", "SignUp"))
        self.user_name.setPlaceholderText(_translate("Form", "Username"))
        self.lineEdit_2.setPlaceholderText(_translate("Form", "Password"))
        self.pushButton.setText(_translate("Form", "R e g i s t e r "))
        self.lineEdit_3.setPlaceholderText(_translate("Form", "Confirm Password"))
        self.lineEdit_4.setPlaceholderText(_translate("Form", "Email Address"))
        self.pushButton_2.setText(_translate("Form", "LogIn"))



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec())